### Actual behaviour
-Tell us what happens

### Expected behaviour
-Tell us what should happen
 
### Steps to reproduce
1. 
2. 
3. 


Can this problem be reproduced with the official owncloud server?
(url: https://demo.owncloud.org, user: test, password: test)


### Environment data
Android version:

Device model: 

Stock or customized system:

ownCloud app version:

ownCloud server version:

### Logs
#### Web server error log
```
Insert your webserver log here
```

#### ownCloud log (data/owncloud.log)
```
Insert your ownCloud log here
```
